!::
! REPLACEMENT TEMPLATE
! A file for keeping all of your last-minute Hugolib replacements together
!::

!\ Routines already replaced by other files:
(update.h)
PrintStatusLine
HugoFix
Parse
ParseError
AssignPronoun

(verbs)
DoSearch
DoListen

(messages)
PrintEndGame
PrintScore
\!

!\#ifset VERSIONS
#message "[NAME].h Version #"
#endif \!


