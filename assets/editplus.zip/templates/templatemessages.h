!::^!
! New Message Stub
!::

! This file serves as a quickstart to modifying default messages

!\#ifset VERSIONS
#message "[NAME].h Version #"
#endif \!

! Contains:
! NewParseError
! NewMessages
! NewOMessages
! NewVMessages
! PrintEndGame
! PrintScore

! changed routine to always print ParseError number if parser
! monitoring is on
replace NewParseError(errornumber, obj) ! to be replaced for custom error
{                                       ! messages for library parsing

#ifset DEBUG
	if debug_flags & D_PARSE and errornumber < 100
	{
		Font(BOLD_ON)
		print "[ParseError("; number errornumber; ", "; obj.name; \
			" ("; number obj; ")]"
		Font(BOLD_OFF)
	}
#endif
	
	select errornumber

	case else : return false
	return true
}

replace NewMessages(r, num, a, b)
{
        select r
#ifset _CHEAPGLK_H 
		 case &CheapCheck : "Hugo detects that you are playing this game
		 on an interpreter that uses the Glk API. Does this interpreter normally
		 have a status bar? (If this question
	confuses you, answer \"yes\")\n"
#endif

#ifset _NEWMENU_H
		case &Menu 
			{
			select num
				case 1
					{
						print "[N]ext item"; to (display.linelength - 11); \
							"[Q]uit menu"
						print "[P]revious item"; to (display.linelength - 17);
						print "[Enter] to select"
					}
				case 2
					{
					! The CheapGlk version is kind of a quick and easy version
					! sure to look good, as some CheapGLK interpreters don't
					! seem to determine linelength correctly.
					print "[N]ext item"; to 25; \
						    "[Q]uit menu"
					print "[P]revious item"; to 25;
					print "[Enter] to select"
					}
				case 3 ! transcript-only text "returning to game"
					"\n[RETURNING TO GAME]"
				case 4
					print "[MENU CHOICE- "; menuitem[a];"]"
			}

		case &CoolPause
			{
			select num
				case 1  ! default top "press a key"
					"\_ [PRESS A KEY TO CONTINUE]";
				case 2  ! default cheapglk "press a key"
					"\_ [PRESS A KEY TO CONTINUE]"
				case 3  ! default normal "press a key"
					"\_\B Press a key to continue...\b";
			}

		case &Help_Hints
			{
			select num
				case 1
					"[Press 'H' for another hint, or 'Q' to quit]";
				case 2
					"\n[No more hints.  Press any key...]";
			}
#endif
		case &PrintEndGame
			{
			select num
				case 1:  print "*** YOU'VE WON THE GAME! ***"
				case 2
				{
					if player_person = 2
						print "*** YOU HAVE DIED ***"
					else
						print "*** "; CThe(player); \
							MatchPlural(player, "has", "have"); \
							" died! ***"
				}
			}

#ifset _SIMPLETALK_H
	case &GetDial
		{
		select num
			case 1
				"Eeeagh! Stage fright! Abort!"
			case 2
				"Select a choice or 0 to keep quiet. >> "
		}
#endif
      case else : return false
 
       return true ! this line is only reached if we replaced something
}

replace NewOMessages(obj, num, a, b)    ! The NewOMessages routine may be
{                                       ! replaced, and should return true
		select obj                        ! if a replacement message <num>
                                        ! exists for object/class <obj>

		case else : return false
		return true
}

replace NewVMessages(r, num, a, b)
{
   select r

#ifset _BETA_H
	case &DoScriptOnOff
		{
		select num
			case 1
				{
				if (transcript_is_on)
					print "Transcription is already on."
				else
					print "Unable to begin transcription."
				}
			case 2:  print "Transcription on."
			case 3
				{
				if (not transcript_is_on)
					print "Transcription is not currently on."
				else
					print "Unable to end transcription."
				}
			case 4: print "Transcription off."
			case 5: print "Comment recorded!"
			case 6: print "Comment not recorded!"
		}
#endif

#ifset _SIMPLETALK_H
	case &DoPhotoTalk
		{
		select num
			case 1
				"You really have nothing to say right now."
		}
#endif
	case else : return false
   return true ! this line is only reached if we replaced something
}

replace PrintEndGame(end_type)
{
	print ""
	Font(BOLD_ON)
	if not NewMessages(&PrintEndGame,end_type)
		{
		select end_type
			case 1:  print "*** YOU'VE WON THE GAME! ***"
			case 2
			{
				if player_person = 2
					print "*** YOU HAVE DIED ***"
				else
					print "*** "; CThe(player); \
						MatchPlural(player, "has", "have"); \
						" died! ***"
			}
		}
 
	Font(BOLD_OFF)
	PrintScore(true)
}

replace PrintScore(end_of_game)
{
	if STATUSTYPE = 1 and MAX_SCORE
	{
		if end_of_game:  print ""
	!\	print "You ";
		if not end_of_game
			print "have ";
		print "scored a total of "; \!
		print "Your score is ";
		print number score; " points out of "; number MAX_SCORE;
	!\	if ranking[0] ~= ""
		{
			print ", giving you the rank of ";
 
			! A complicated formula, since only
			! integer division is allowed:
			!
			print ranking[(score*MAX_RANK)/MAX_SCORE];
		} \!
		print ", in "; number counter ; " move";
		if counter > 1
			"s";
		print "."
	}
}
