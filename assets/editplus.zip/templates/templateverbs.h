!::^!
! More Verbs
!::

!\#ifset VERSIONS
#message "[NAME].h Version #"
#endif \!

! Contains the verbs:
! DoPushDir
! DoSearch (fix)
! DoListen (fix)

routine DoPushDir
{
	"That would not help the present situation."
   ! let's not use up a turn
}

! this had some weird pronoun stuff
#ifset _VERBSTUB_H
replace DoSearch
{
	if object = player
	{
		"Search ";
		The(player)
		" indeed."
	}
	elseif object is container and child(object)
		Perform(&DoLookIn, object)
	elseif object is living
	{
		print CThe(object); MatchPlural(object, "doesn't", "don't");
		" let ";
		The(player)
		if object.pronouns
		{
			" search ";
			if object.pronouns #2
				print object.pronouns #2;
			else
				print object.pronoun;
		}
		print "."
	}
	else
	{
		CThe(player)
		MatchPlural(player, "doesn't", "don't")
		" find anything new."
	}
	return true
}
#endif


replace DoListen
{
	if not object
		{
			if not location.after
				{
				VMessage(&DoListen, 1)  ! "Be a little more specific..."
				return false
				}
			verbroutine = ""
			return true
		}
	elseif not object.after
		VMessage(&DoListen, 2)   ! "Not making any sound..."
	! we have to clear verbroutine or else location.after.DoListen will run again
	verbroutine = ""
	return true
}