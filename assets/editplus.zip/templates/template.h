!::
! EXTENSION NAME
!::

!\#ifset VERSIONS
#message "[NAME].h Version #"
#endif \!


